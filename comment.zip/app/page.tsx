"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useUser } from "@/contexts/UserContext";
import { withAuth } from "@/hoc/withAuth";
import Layout from "@/layout/Layout";

// UI Components
import { Button } from "@/components/ui/button";
import FacebookInfo from "@/components/FacebookInfo";
import InstagramInfo from "@/components/InstagramInfo";
import UpgradePlan from "@/app/dashboard/package/components/UpgradePlan";

// Icons
import { 
  Sparkles, 
  Rocket, 
  ShieldCheck, 
  ArrowUpRight, 
  Zap, 
  LogOut, 
  Clock,
  MessageCircle,
  BarChart3,
  Calendar,
  Users
} from "lucide-react";
import FeatureSection from "@/components/FeatureSection";
import Con from "@/components/Con";
import InstagramInfoCard from "@/components/InstagramSection";
import { useInstagram } from "@/contexts/InstagramContext";


function Home() {
  const router = useRouter();
  const { user, loading } = useUser();
  const {user: instaUser} = useInstagram()
  const [isUpgradeOpen, setIsUpgradeOpen] = useState(false);

  const handleLogout = async () => {
    localStorage.removeItem("token");
    localStorage.removeItem("email");
    await signOut(auth);
    router.refresh();
    router.replace("/login");
  };

  if (loading) {
    return (
      <Layout>
        <div className="max-w-6xl mx-auto px-4 py-12 animate-pulse space-y-8">
          <div className="h-64 bg-gray-100 rounded-3xl" />
          <div className="grid grid-cols-3 gap-6">
            <div className="h-32 bg-gray-100 rounded-2xl" />
            <div className="h-32 bg-gray-100 rounded-2xl" />
            <div className="h-32 bg-gray-100 rounded-2xl" />
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
        
        {/* --- SECTION 1: WHITE HERO --- */}
        <section className="relative overflow-hidden rounded-3xl border border-slate-200 bg-white p-8 md:p-12 shadow-sm">
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-orange-50 rounded-full blur-3xl opacity-60" />
          
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="space-y-4 text-center md:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-50 border border-orange-100 text-orange-600 text-[10px] font-bold uppercase tracking-[0.2em]">
                <Sparkles className="w-3 h-3" /> Growth Engine Active
              </div>
              
              <h1 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight">
                Welcome, <span className="text-orange-500">{user?.name?.split(' ')[0] || "Chief"}!</span>
              </h1>
              
              <p className="text-slate-500 max-w-md text-lg font-medium leading-relaxed">
                Your social automation is ready. Connect your pages and start scaling your brand.
              </p>
            </div>
            
            {/* PRICING CARD */}
            <div className="bg-white border border-slate-100 shadow-xl shadow-slate-200/50 p-8 rounded-3xl w-full md:w-80 group">
              <div className="space-y-1 mb-6">
                <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Premium Access</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-black text-slate-900">৳ 299</span>
                  <span className="text-slate-400 font-medium text-sm">/page/mo</span>
                </div>
              </div>

              <Button 
                onClick={() => setIsUpgradeOpen(true)}
                className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold h-12 rounded-xl shadow-lg shadow-orange-200 active:scale-95 flex gap-2"
              >
                Boost My Page <Rocket className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </section>

        {/* --- SECTION 2: TRIAL & SYNC --- */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-4 p-6 rounded-3xl border-2 border-orange-500/10 bg-orange-50/30 flex flex-col justify-between hover:border-orange-500/30 transition-all">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white shadow-sm text-orange-500 rounded-2xl">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-bold text-orange-600 uppercase tracking-widest">Free Trial</p>
                <h3 className="text-xl font-bold text-slate-900">7 Days Free</h3>
              </div>
            </div>
            <p className="mt-4 text-sm text-slate-600">
              Try every premium feature for 1 week. No payment required to start.
            </p>
          </div>

          <div className="md:col-span-8 p-6 rounded-3xl border border-slate-200 bg-white flex items-center justify-between hover:shadow-lg hover:shadow-slate-100 transition-all">
            <div className="space-y-1">
              <h3 className="text-xl font-extrabold text-slate-900">Omnichannel Sync</h3>
              <p className="text-slate-500 text-sm font-medium">Manage Facebook & Instagram in one place.</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex -space-x-2 text-xs font-bold">
                <div className="w-10 h-10 rounded-full bg-blue-600 border-2 border-white flex items-center justify-center text-white">f</div>
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600 border-2 border-white flex items-center justify-center text-white">i</div>
              </div>
            </div>
          </div>
        </div>

        {/* --- SECTION 3: FEATURES --- */}
        {/* <FeatureSection/> */}

        <div className="grid grid-cols-2 gap-6 w-full">
          <Con/>
          <InstagramInfoCard instaUser={instaUser}/>
        </div>
        


        {/* --- SECTION 4: ACCOUNT STATUS --- */}
        <div className="space-y-6 pt-8">
          <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
            Connected Accounts <div className="h-1 w-1 bg-slate-300 rounded-full" />
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm">
              <FacebookInfo />
            </div>
            <div className="bg-white rounded-3xl border border-slate-100 p-6 shadow-sm">
              <InstagramInfo />
            </div>
          </div>
        </div>

        {/* --- FOOTER --- */}
        <footer className="pt-12 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 text-slate-400 text-sm">
            <Clock className="w-4 h-4" />
            <span>Support active: 10:00 AM — 10:00 PM</span>
          </div>
          <div className="flex gap-4">
            <Button 
              variant="ghost" 
              onClick={handleLogout} 
              className="text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl"
            >
              <LogOut className="w-4 h-4 mr-2" /> Logout
            </Button>
          </div>
        </footer>

        {/* UPGRADE DIALOG */}
        <UpgradePlan 
          isOpen={isUpgradeOpen} 
          onClose={() => setIsUpgradeOpen(false)} 
        />
      </div>
    </Layout>
  );
}

export default withAuth(Home);